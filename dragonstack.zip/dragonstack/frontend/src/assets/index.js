import skinny from './skinny.png';
import patchy from './patchy.png';
import plain from './plain.png';
import slender from './slender.png';
import sporty from './sporty.png';
import spotted from './spotted.png';
import stocky from './stocky.png';
import striped from './striped.png';

export {skinny, slender, patchy, plain, sporty, spotted, stocky, striped};
