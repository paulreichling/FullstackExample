module.exports = {
    user: 'node_user',
    host: 'localhost', 
    database: 'dragonstackdb',
    password: 'node_password',
    post: 5432
};